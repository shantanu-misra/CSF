MS1 (8/30): Added support for uint256_create_from_u32, uint256_create, uint256_get_bits.
