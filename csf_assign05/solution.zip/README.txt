Sample README.txt

Contributions:
Shantanu: Connection, sender, receiver,
Sebastian: receiver, client_utils

Eventually your report about how you implemented thread synchronization
in the server should go here
