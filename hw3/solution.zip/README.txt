ISSUES:
1. 
2. BIGGEST ISSUE: the writes don't really work. write allocate, write back etc 
3. MAJOR ISSUE: Clock cycles are like...50% less